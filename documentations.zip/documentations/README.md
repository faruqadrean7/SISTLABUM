# Dokumentasi Screenshot SISTLABUM (Web & Portal)

Dokumentasi ini **hanya mencakup aplikasi Web dan Portal** sesuai instruksi. Tidak memuat screenshot projek admin, mobile, ataupun backend.

---

## 📁 Struktur Direktori

```
documentations/
│
├── web/                                  # Port 3000 (Website Publik & Dashboard PPDB)
│   ├── 01_beranda.png                    # Beranda Utama
│   ├── 02_profil.png                     # Profil Sekolah
│   ├── 03_akademik.png                   # Program Akademik
│   ├── 04_berita.png                     # Berita & Agenda
│   ├── 05_galeri.png                     # Galeri Foto Kegiatan
│   ├── 06_kontak.png                     # Kontak & Lokasi
│   ├── 07_ppdb_informasi.png             # Informasi & Alur PPDB
│   ├── 08_ppdb_daftar.png                # Formulir Registrasi Akun Calon Siswa
│   ├── 09_ppdb_masuk.png                 # Halaman Masuk Akun PPDB
│   └── 10_ppdb_dashboard.png             # Dashboard Calon Siswa (Login: muhfattah@gmail.com / 123456789)
│
└── portal/                               # Port 3001 (Portal Mandiri Warga Sekolah)
    ├── 01_portal_login.png               # Halaman Login Portal (Kartu Quick Preset)
    │
    ├── 02_guru_dashboard.png             # [GURU] Dashboard Utama (Login: Guru)
    ├── 03_guru_jadwal.png                # [GURU] Jadwal Mengajar
    ├── 04_guru_materi.png                # [GURU] Modul Ajar / Bahan Ajar
    ├── 05_guru_tugas.png                 # [GURU] Manajemen Tugas Siswa
    ├── 06_guru_nilai.png                 # [GURU] Buku Nilai Ledger
    ├── 07_guru_jurnal.png                # [GURU] Jurnal Mengajar & Presensi
    ├── 08_guru_perizinan.png             # [GURU] Pengajuan Izin / Cuti
    ├── 09_guru_sarpras.png               # [GURU] Peminjaman Fasilitas & Sarpras
    ├── 10_guru_siswa.png                 # [GURU] Data Siswa Binaan
    ├── 11_guru_cbt.png                   # [GURU] Bank Soal & Ujian CBT
    │
    ├── 12_siswa_dashboard.png            # [SISWA] Dashboard Siswa (Login: Siswa)
    ├── 13_siswa_jadwal.png               # [SISWA] Jadwal Pelajaran
    ├── 14_siswa_tugas.png                # [SISWA] Tugas & PR
    ├── 15_siswa_nilai.png                # [SISWA] Rapor & Riwayat Nilai
    ├── 16_siswa_poin.png                 # [SISWA] Poin Prestasi & Pelanggaran
    ├── 17_siswa_cbt.png                  # [SISWA] Ujian CBT Online
    ├── 18_siswa_konseling.png            # [SISWA] Layanan BK / Konseling
    │
    ├── 19_ortu_dashboard.png             # [WALI MURID] Dashboard Orang Tua (Login: Wali Murid)
    ├── 20_ortu_presensi.png              # [WALI MURID] Presensi & Kehadiran Anak
    ├── 21_ortu_nilai.png                 # [WALI MURID] Rekap Nilai Akademik Anak
    ├── 22_ortu_poin.png                  # [WALI MURID] Catatan Karakter & Poin Siswa
    ├── 23_ortu_biaya.png                 # [WALI MURID] Rincian Tagihan & SPP
    └── 24_ortu_konseling.png             # [WALI MURID] Konseling & Komunikasi Guru BK
```

---

## 🔑 Kredensial & Autentikasi Pengambilan Screenshot

| Target | Halaman | Metode Autentikasi | Kredensial / Aksi |
|---|---|---|---|
| **Web PPDB** | `http://localhost:3000/ppdb/masuk` | Form Login Biasa | **Email**: `muhfattah@gmail.com`<br>**Password**: `123456789` |
| **Portal Guru** | `http://localhost:3001/login` | Quick Preset Card | Klik kartu **Guru** (`guru.mtk`) lalu klik **Masuk** |
| **Portal Siswa** | `http://localhost:3001/login` | Quick Preset Card | Klik kartu **Siswa** (`siswa.lab.001`) lalu klik **Masuk** |
| **Portal Wali Murid** | `http://localhost:3001/login` | Quick Preset Card | Klik kartu **Wali Murid** (`ortu.siswa.001`) lalu klik **Masuk** |

---

## 🚀 Perintah Menjalankan Skrip

1. **Jalankan Semua (Khusus Web Publik + PPDB + Portal)**:
   ```bash
   node scripts/take-all-screenshots.js
   ```

2. **Hanya Folder Portal**:
   ```bash
   node scripts/take-all-screenshots.js --portal
   ```

3. **Hanya Folder Web (Publik & PPDB)**:
   ```bash
   node scripts/take-all-screenshots.js --web
   ```

4. **Testing 1 Halaman Saja**:
   - Guru Dashboard: `node scripts/take-all-screenshots.js --guru --single`
   - PPDB Dashboard: `node scripts/take-all-screenshots.js --ppdb`
   - Siswa Dashboard: `node scripts/take-all-screenshots.js --siswa --single`
   - Ortu Dashboard: `node scripts/take-all-screenshots.js --ortu --single`

